Add your tls server certificate, key and the CA certificate (if any) here
or during docker run mount a data volume with those files to /container/service/slapd/assets/certs
