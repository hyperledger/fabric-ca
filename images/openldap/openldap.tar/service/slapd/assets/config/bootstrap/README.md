Bootstrap config, for a container started without an existing ldap config.
